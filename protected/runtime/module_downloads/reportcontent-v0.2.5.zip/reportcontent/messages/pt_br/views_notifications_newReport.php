<?php
return array (
  'An user has reported your post as offensive.' => 'Um usuário marcou seu post como ofensivo.',
  'An user has reported your post as spam.' => 'Um usuário marcou seu post como spam.',
  'An user has reported your post for not belonging to the space.' => 'Um usuário marcou seu post como não relacionado a este espaço.',
);
