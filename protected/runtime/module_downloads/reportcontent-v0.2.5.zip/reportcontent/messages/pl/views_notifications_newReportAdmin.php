<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% zgłosił %contentTitle% jako obraźliwe.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% zgłosił %contentTitle% jako spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% zgłosił %contentTitle% jako nie pasujące do strefy.',
);
