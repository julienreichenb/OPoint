<?php
return array (
  'Here you can manage reported users posts.' => 'W tym miejscu możesz zarządzać zgłoszonymi treściami.',
);
