<?php
return array (
  'Doesn\'t belong to space' => 'Nie należy do strefy',
  'Offensive' => 'Obraźliwe',
  'Spam' => 'Spam',
);
