<?php
return array (
  'An user has reported your post as offensive.' => '',
  'An user has reported your post as spam.' => '',
  'An user has reported your post for not belonging to the space.' => '',
);
