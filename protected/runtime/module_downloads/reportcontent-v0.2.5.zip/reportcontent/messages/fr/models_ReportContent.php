<?php
return array (
  'Doesn\'t belong to space' => 'Ne concerne pas cet espace',
  'Offensive' => 'Choquant',
  'Spam' => 'Spam',
);
