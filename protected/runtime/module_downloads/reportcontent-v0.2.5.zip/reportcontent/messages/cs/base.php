<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Spravovat <strong>nahlášené příspěvky</strong>',
  'Please provide a reason, why you want to report this content.' => 'Prosím udejte důvod, proč jste nahlásili tento příspěvek.',
  'Reported posts' => 'Nahlášené příspěvky',
  'Why do you want to report this post?' => 'Proč chcete nahlásit tento příspěvek?',
  'by :displayName' => 'od:displayName',
  'created by :displayName' => 'vytvořil/a:displayName',
);
