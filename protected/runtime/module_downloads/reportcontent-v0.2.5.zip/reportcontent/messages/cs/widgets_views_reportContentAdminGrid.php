<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Potvrzení</strong> smazání příspěvku',
  '<strong>Confirm</strong> report deletion' => '<strong> Potvrďte </ strong> odstranění reportu.',
  'Approve' => 'Povolit',
  'Approve post' => 'Povolit příspěvek',
  'Cancel' => 'Zrušit',
  'Content' => 'Příspěvky',
  'Delete' => 'Smazat',
  'Delete post' => 'Smazat příspěvek ',
  'Do you really want to approve this post?' => 'Opravdu chcete tento příspěvek schválit?',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Opravdu chcete smazat tento příspěvek? Všechny komentáře a označení Libí se mi budou smazány.',
  'Reason' => 'Důvod',
  'Reporter' => 'Nahlašovatel',
  'There are no reported posts.' => 'Neexistují žádné hlášené příspěvky.',
);
