<?php
return array (
  'Does not belong here' => 'Nepatří sem',
  'Help Us Understand What\'s Happening' => 'Popište nám co se stalo',
  'It\'s offensive' => 'Toto je urážlivé',
  'It\'s spam' => 'Nevyžádané',
  'Report post' => 'Nahlásit příspěvek',
  'Submit' => 'Potvrdit',
);
