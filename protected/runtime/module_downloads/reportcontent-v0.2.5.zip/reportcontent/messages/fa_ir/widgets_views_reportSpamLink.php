<?php
return array (
  'Does not belong here' => 'به اين انجمن تعلق ندارد',
  'Help Us Understand What\'s Happening' => 'به ما در فهميدن اوضاع كمك كنيد',
  'It\'s offensive' => 'توهين آميز است',
  'It\'s spam' => 'تبليغ است',
  'Report post' => 'گزارش',
  'Submit' => 'ارسال',
);
