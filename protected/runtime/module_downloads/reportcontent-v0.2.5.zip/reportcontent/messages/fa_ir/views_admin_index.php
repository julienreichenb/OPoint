<?php
return array (
  'Here you can manage reported users posts.' => 'شما می‌توانید در این قسمت پست‌های گزارش‌شده‌ي کاربران را مدیریت کنید.',
);
