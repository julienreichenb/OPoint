<?php
return array (
  'Doesn\'t belong to space' => 'متعلق به انجمن نیست',
  'Offensive' => 'توهین‌آمیز',
  'Spam' => 'Spam',
);
