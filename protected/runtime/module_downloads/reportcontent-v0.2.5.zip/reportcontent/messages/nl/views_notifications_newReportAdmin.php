<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% heeft %contentTitle% gemarkeerd als beledigend.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% heeft %contentTitle% gemarkeerd als spam.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% heeft %contentTitle% gemarkeerd voor niet horen in de space.',
);
