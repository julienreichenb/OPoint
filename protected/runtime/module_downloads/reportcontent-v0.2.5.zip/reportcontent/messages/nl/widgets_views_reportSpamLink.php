<?php
return array (
  'Does not belong here' => 'Hoort hier niet.',
  'Help Us Understand What\'s Happening' => 'Help ons te begrijpen wat er gebeurd.',
  'It\'s offensive' => 'Het is beledigend',
  'It\'s spam' => 'Het is spam',
  'Report post' => 'Rapporteer bericht',
  'Submit' => 'Verzend',
);
