<?php
return array (
  'An user has reported your post as offensive.' => 'Een gebruiker heeft je post gemarkeerd als beledigend.',
  'An user has reported your post as spam.' => 'Een gebruiker heeft je post gemarkeerd als spam.',
  'An user has reported your post for not belonging to the space.' => 'Een gebruiker heeft je post gemarkeerd als: Hoort niet thuis in space.',
);
