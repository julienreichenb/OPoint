<?php
return array (
  'Doesn\'t belong to space' => 'Не принадлежит к пространству',
  'Offensive' => 'Оскорбление',
  'Spam' => 'Спам',
);
