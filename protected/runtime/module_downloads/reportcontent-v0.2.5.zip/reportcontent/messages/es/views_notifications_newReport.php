<?php
return array (
  'An user has reported your post as offensive.' => 'Un usuario ha reportado tu entrada como ofensiva.',
  'An user has reported your post as spam.' => 'Un usuario ha reportado tu entrada como spam.',
  'An user has reported your post for not belonging to the space.' => 'Un usuario ha reportado tu entrada por no pertenecer al espacio.',
);
