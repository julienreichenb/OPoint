<?php
return array (
  '<strong>Confirm</strong> post deletion' => '<strong>Bekreft</strong> sletting av innlegg',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Avbryt',
  'Content' => 'Innhold',
  'Delete' => 'Slett',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'Ønsker du virkelig og slette denne posten? Alle likes og kommentarer vil bli tapt!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
