<?php
return array (
  '<strong>Confirm</strong> post deletion' => '
<strong>Confirmar</strong> l\'eliminació del post
',
  '<strong>Confirm</strong> report deletion' => '',
  'Approve' => '',
  'Approve post' => '',
  'Cancel' => 'Cancel·la',
  'Content' => 'Contingut',
  'Delete' => 'Suprimeix',
  'Delete post' => '',
  'Do you really want to approve this post?' => '',
  'Do you really want to delete this post? All likes and comments will be lost!' => 'De veritat vol eliminar aquest post? Tots els m\'agrada i els comentaris es perdran!',
  'Reason' => '',
  'Reporter' => '',
  'There are no reported posts.' => '',
);
