<?php
return array (
  'An user has reported your post as offensive.' => 'Saldırgan olarak bildirildi.',
  'An user has reported your post as spam.' => 'Spam mesaj olarak bildirildi.',
  'An user has reported your post for not belonging to the space.' => 'Mekana ait olmayan yazı için bildirildi.',
);
