<?php
return array (
  'Does not belong here' => 'Bu mekana ait değil',
  'Help Us Understand What\'s Happening' => 'Ne Olduğunu Anlamamıza Yardımcı Ol',
  'It\'s offensive' => 'Saldırgan içerik',
  'It\'s spam' => 'Spam mesaj',
  'Report post' => 'Mesajı bildir',
  'Submit' => 'Gönder',
);
