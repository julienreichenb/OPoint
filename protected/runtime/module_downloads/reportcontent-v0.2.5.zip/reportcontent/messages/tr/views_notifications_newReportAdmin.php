<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% tarafından %contentTitle% mesajı saldırgan olarak bildirildi.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% tarafından %contentTitle% mesajı spam olarak bildirildi.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% tarafından %contentTitle% mesajı mekana ait değil olarak bildirildi.',
);
