<?php
return array (
  'Here you can manage reported posts for this space.' => 'Ovdje možete upravljati prijavljenim objavamaza ovaj prostor.',
);
