<?php
return array (
  'Manage <strong>reported posts</strong>' => 'Quản lý <strong>bài post bị tố cáo</strong>',
  'Please provide a reason, why you want to report this content.' => 'Vui lòng cung cấp lý do vì sao bạn tố cáo nội dung này.',
  'Reported posts' => 'Tố cáo post',
  'Why do you want to report this post?' => 'Tại sao bạn muốn tố cáo bài post này?',
  'by :displayName' => 'bởi :displayName',
  'created by :displayName' => 'tạo bởi :displayName',
);
