<?php
return array (
  'Does not belong here' => 'Không thuộc về nơi đây',
  'Help Us Understand What\'s Happening' => 'Giúp chúng tôi hiểu chuyện gì đang diễn ra',
  'It\'s offensive' => 'Nội dung PHẢN CẢM',
  'It\'s spam' => 'Nội dung SPAM',
  'Report post' => 'Tố cáo post',
  'Submit' => 'Đăng cảm nghĩ',
);
