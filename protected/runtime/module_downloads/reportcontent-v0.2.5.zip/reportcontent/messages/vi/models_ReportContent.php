<?php
return array (
  'Doesn\'t belong to space' => 'Không thuọc về phòng',
  'Offensive' => 'Phản cảm',
  'Spam' => 'SPAM',
);
