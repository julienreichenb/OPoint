<?php
return array (
  '%displayName% has reported %contentTitle% as offensive.' => '%displayName% đã tố cáo %contentTitle% là PHẢN CẢM.',
  '%displayName% has reported %contentTitle% as spam.' => '%displayName% đã tố cáo %contentTitle% là SPAM.',
  '%displayName% has reported %contentTitle% for not belonging to the space.' => '%displayName% đã tố cáo %contentTitle% không thích hợp thuộc về phòng.',
);
