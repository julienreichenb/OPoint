<?php

return [
    'snippet' => '',
];
