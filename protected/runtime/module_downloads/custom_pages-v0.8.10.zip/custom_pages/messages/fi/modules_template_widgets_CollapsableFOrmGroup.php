<?php

return [
    'Show less' => '',
    'Show more' => '',
];
