<?php

return [
    'Save' => 'Tallenna',
];
