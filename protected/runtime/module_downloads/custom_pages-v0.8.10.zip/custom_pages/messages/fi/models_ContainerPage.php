<?php

return [
    'Only visible for space admins' => 'Näkyvissä vain sivun ylläpitäjille',
    'Open in new window' => 'Avaa uusi uuteen ikkunaan',
    'page' => 'sivu',
];
