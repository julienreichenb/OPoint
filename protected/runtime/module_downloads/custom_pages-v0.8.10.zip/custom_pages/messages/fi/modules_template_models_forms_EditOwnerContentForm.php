<?php

return [
    'Use default content' => '',
];
