<?php

return [
    'Height' => '',
    'Style' => '',
    'Width' => '',
];
