<?php
return array (
  'Create new {type}' => 'አዲስ {type} ይፍጠሩ',
  'Edit template \'{templateName}\'' => 'የ\'{templateName}\' አብነትን አስተካክል',
  'Save' => 'አስቀምጥ',
);
