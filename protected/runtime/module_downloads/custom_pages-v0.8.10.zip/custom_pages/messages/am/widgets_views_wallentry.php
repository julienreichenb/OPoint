<?php
return array (
  'Open page...' => 'ገፁ እየተከፈተ ነው',
);
