<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'የቁንፅልመረጃዎን አቀማመጥ እዚህ ማስተካከል ይችላሉ። ቁንፅልመረጃዎች በጎን ገፅታ ላይ መካተት የሚችሉ አብነቶች ናቸው። ',
);
