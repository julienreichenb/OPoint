<?php
return array (
  'Edit Template' => 'አብነቱን ያርትዑ',
  'Edit elements' => 'አካላቶቹን ያርትዑ',
  'Edit template' => 'አብነቱን ያርትዑ',
  'Page configuration' => 'የገፅ ማዋቀሪያ',
  'Turn edit off' => 'አርትዑን ያጥፉ',
);
