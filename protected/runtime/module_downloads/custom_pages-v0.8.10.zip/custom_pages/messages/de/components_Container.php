<?php
return array (
  'Content' => 'Inhalt',
  'ID' => 'ID',
  'Icon' => 'Symbol',
  'Invalid template selection!' => 'Ungültige Vorlagenauswahl!',
  'Invalid view file selection!' => 'Ungültige View-Dateiauswahl!',
  'Sort Order' => 'Sortierung',
  'Style Class' => 'Style Klasse',
  'Target Url' => 'Ziel URL',
  'Template Layout' => 'Vorlagen Layout',
  'Title' => 'Titel',
  'Type' => 'Typ',
);
