<?php
return array (
  'Choose a template' => 'Vorlage auswählen',
  'Template' => 'Vorlage',
);
