<?php
return array (
  'less' => 'weniger',
  'more' => 'mehr',
);
