<?php
return array (
  'Empty <br />Container' => 'Leerer <br />Container',
);
