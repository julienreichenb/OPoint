<?php
return array (
  'Update download failed! (%error%)' => 'Download aggiornamento fallito! (%error%)',
);
