<?php

return [
    'Drag list' => '',
];
