<?php

return [
    'Created by me' => '',
    'Filter tasks' => '',
    'I\'m assigned' => '',
    'I\'m responsible' => '',
    'Overdue' => '',
    'Status' => '',
];
