<?php

return [
    'Your Reminder for task {task}' => '',
];
