<?php
return array (
  'Click, to finish this task' => 'Klikni, da završiš zadatak',
  'This task is already done. Click to reopen.' => 'Ovaj zadatak je već izvršen. Klikni za reotvaranje.',
);
