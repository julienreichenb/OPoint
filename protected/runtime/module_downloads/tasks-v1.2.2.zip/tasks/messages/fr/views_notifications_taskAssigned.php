<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} vous a affecté à la tâche {task}.',
);
