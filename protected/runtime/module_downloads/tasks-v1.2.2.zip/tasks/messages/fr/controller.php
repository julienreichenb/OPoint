<?php
return array (
  'Already requested' => '',
  'Request sent' => 'Requête envoyée',
  'You have insufficient permissions to perform that operation!' => '',
);
