<?php
return array (
  '{userName} completed task {task}.' => '{userName} a complété la tâche {task}.',
  '{userName} reset task {task}.' => '',
  '{userName} reviewed task {task}.' => '',
  '{userName} works on task {task}.' => '{userName} travaille sur la tâche {task}.',
);
