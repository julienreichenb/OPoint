<?php
return array (
  'Could not access task!' => 'Impossible d\'accéder aux tâches.',
);
