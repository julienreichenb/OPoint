<?php
return array (
  'Anyone can work on this task!' => '',
  'Open Task' => 'Ouvrir',
  'This task can only be processed by assigned and responsible users.' => '',
);
