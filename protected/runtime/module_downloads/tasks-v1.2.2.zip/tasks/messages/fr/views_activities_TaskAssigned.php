<?php
return array (
  '{userName} assigned to task {task}.' => '{userName} a été affecté à la tâche {task}.',
);
