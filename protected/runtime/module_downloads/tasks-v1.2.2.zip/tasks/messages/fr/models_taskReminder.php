<?php
return array (
  '1 Day before' => '1 jour avant',
  '1 Month before' => '1 mois avant',
  '1 Week before' => '1 semaine avant',
  '2 Days before' => '2 jours avant',
  '2 Weeks before' => '2 semaines avant',
  '3 Weeks before' => '3 semaines avant',
  'At least 1 Hour before' => '',
  'At least 2 Hours before' => '',
  'Do not remind' => 'Ne pas rappeller',
  'Remind Mode' => '',
  'Task' => 'Tâche',
);
