<?php
return array (
  '<strong>Task</strong> module configuration' => 'Paramétrage du module <strong>Tâches</strong>',
  'Max tasks items' => '',
  'Show snippet' => 'Afficher un extrait',
  'Show snippet in Space' => 'Afficher un extrait dans l\'espace',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => '',
  'Shows the widget also on the dashboard of spaces.' => '',
  'Sort order' => 'Ordre de tri',
  'Your tasks snippet' => '',
);
