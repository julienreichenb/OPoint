<?php
return array (
  '<strong>Confirm</strong> deleting' => '',
  'Add Task' => '',
  'Cancel' => '',
  'Delete' => 'Διαγραφή',
  'Do you really want to delete this task?' => '',
  'No open tasks...' => '',
  'completed tasks' => '',
);
