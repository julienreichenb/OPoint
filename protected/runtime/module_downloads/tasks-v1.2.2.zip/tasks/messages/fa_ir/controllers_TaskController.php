<?php
return array (
  'Could not access task!' => 'دسترسی به کار مورد نظر امکان‌پذیر نیست!',
);
