<?php
return array (
  'Could not access task!' => 'No s\'ha pogut accedir a la tasca!',
);
