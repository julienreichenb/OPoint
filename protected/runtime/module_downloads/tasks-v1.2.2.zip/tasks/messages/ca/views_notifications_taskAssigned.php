<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} t\'ha assignat la tasca {task}.',
);
