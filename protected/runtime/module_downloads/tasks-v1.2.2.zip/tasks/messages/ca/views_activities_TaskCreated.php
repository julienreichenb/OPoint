<?php
return array (
  '{userName} created task {task}.' => '{userName} ha creat la tasca {task}.',
);
