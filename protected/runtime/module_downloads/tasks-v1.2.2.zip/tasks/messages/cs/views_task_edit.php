<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Vytvořit</strong> nový úkol',
  '<strong>Edit</strong> task' => '<strong>Upravit</strong> úkol',
  'Assign users' => 'Přiřaďte uživatele',
  'Cancel' => 'Zrušit',
  'Deadline' => 'Lhůta',
  'Save' => 'Uložit',
  'What is to do?' => 'Co je potřeba udělat?',
);
