<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Nejsou zde žádné úkoly!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Zatím zde nejsou žádné úkoly.</b><br> Vytvořte první...',
  'Assigned to me' => 'Přiřazených mně',
  'Back to stream' => '@@Zpět na příspěvky@@',
  'Created by me' => 'Vytvořil(a) jsem',
  'Creation time' => 'Vytvořeno',
  'Filter' => 'Filtr',
  'Last update' => 'Změněno',
  'No tasks found which matches your current filter(s)!' => '@@Nebyl nalezen žádný úkol, který by odpovídal filtrům, které jste zvolil(a).@@',
  'Nobody assigned' => 'Nepřiřazen nikomu',
  'Sorting' => 'Řazení',
  'State is finished' => 'Dokončené',
  'State is open' => 'Otevřené',
);
