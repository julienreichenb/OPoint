<?php
return array (
  'Assign users to this task' => '',
  'Deadline for this task?' => '',
  'Preassign user(s) for this task.' => '',
  'What to do?' => '',
);
