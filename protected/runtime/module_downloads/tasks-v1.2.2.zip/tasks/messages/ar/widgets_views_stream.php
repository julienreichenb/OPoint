<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Created by me' => 'التي كتبتها أنا',
  'Creation time' => 'حسب وقت النشر',
  'Filter' => 'تصفية',
  'Last update' => 'حسب آخر تعديل',
  'Nobody assigned' => '',
  'Sorting' => 'الترتيب',
  'State is finished' => '',
  'State is open' => '',
);
