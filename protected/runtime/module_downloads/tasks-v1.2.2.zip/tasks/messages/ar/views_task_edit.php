<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'إلغاء',
  'Deadline' => '',
  'Save' => 'حفظ',
  'What is to do?' => '',
);
