<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Confirmar</strong> borrar',
  'Add Task' => 'Agregar Tarea',
  'Cancel' => 'Cancelar',
  'Delete' => 'Borrar',
  'Do you really want to delete this task?' => '¿Realmente deseas borrar esta tarea?',
  'No open tasks...' => 'No hay tareas abiertas',
  'completed tasks' => 'tareas completadas',
);
