<?php

return [
    '{userName} completed task {task}.' => '{userName} hat die Aufgabe {task} fertiggestellt.',
    '{userName} reset task {task}.' => '{userName} hat die Aufgabe {task} zurückgesetzt.',
    '{userName} reviewed task {task}.' => '{userName} hat die Aufgabe {task} überprüft.',
    '{userName} works on task {task}.' => '{userName} arbeitet an der Aufgabe {task}.',
];
