<?php
return array (
  'Anyone can work on this task!' => 'Jeder kann an dieser Aufgabe arbeiten',
  'Open Task' => 'Zur Aufgabe',
  'This task can only be processed by assigned and responsible users.' => 'Diese Aufgabe kann nur von zugewiesenen und verantwortlichen Benutzern bearbeitet werden.',
);
