<?php
return array (
  '<strong>Task</strong> module configuration' => '<strong>Task</strong> Modul Konfiguration',
  'Max tasks items' => 'Maximale Aufgabenelemente',
  'Show snippet' => 'Zeige das Widget',
  'Show snippet in Space' => 'Zeige das Widget im Space',
  'Shows a widget with tasks on the dashboard where you are assigned/responsible.' => 'zeigt ein Widget mit Aufgaben auf dem Dashboard, wo Du zugewiesen/verantwortlich bist.',
  'Shows the widget also on the dashboard of spaces.' => 'Zeigt das Widget auch auf dem Dashboard von Spaces an.',
  'Sort order' => 'Sortierreihenfolge',
  'Your tasks snippet' => 'Dein Task Widget',
);
