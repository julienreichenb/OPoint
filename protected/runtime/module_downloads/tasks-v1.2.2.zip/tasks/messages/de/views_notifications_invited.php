<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} hat dich als verantwortliche Person für die Aufgabe {task} im Space {spaceName} zugeordnet.',
);
