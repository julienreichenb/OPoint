<?php
return array (
  '{userName} finished task {task}.' => '{userName} hat die Aufgabe »{task}« abgeschlossen.',
);
