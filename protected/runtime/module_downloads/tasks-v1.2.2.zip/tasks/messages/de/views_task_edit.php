<?php
return array (
  '<strong>Create</strong> new task' => 'Neue Aufgabe <strong>erstellen</strong>',
  '<strong>Edit</strong> task' => 'Aufgabe <strong>bearbeiten</strong> ',
  'Assign users' => 'Benutzer zuordnen',
  'Cancel' => 'Abbrechen',
  'Deadline' => 'Frist',
  'Save' => 'Speichern',
  'What is to do?' => 'Was ist zu tun?',
    'Assignment' => 'Zuweisung',


);
