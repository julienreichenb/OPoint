<?php
return array (
  'Task Users have been notified' => 'Aufgaben-Benutzer wurden benachrichtigt',
);
