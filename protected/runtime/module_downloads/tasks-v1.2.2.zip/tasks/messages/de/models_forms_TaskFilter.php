<?php

return [
    'Created by me' => 'Von mir erstellt',
    'Filter tasks' => 'Aufgaben filtern',
    'I\'m assigned' => 'Mir zugewiesen',
    'I\'m responsible' => 'Ich bin verantwortlich',
    'Overdue' => 'Überfällig',
    'Status' => 'Status',
];
