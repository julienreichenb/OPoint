<?php
return array (
  '<strong>Create</strong> new task' => '',
  '<strong>Edit</strong> task' => '',
  'Assign users' => '',
  'Cancel' => 'Отказ',
  'Deadline' => '',
  'Save' => 'Запази',
  'What is to do?' => '',
);
