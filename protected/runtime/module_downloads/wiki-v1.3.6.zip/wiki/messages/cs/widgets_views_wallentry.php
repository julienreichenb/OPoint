<?php
return array (
  'Open wiki page...' => 'Otevřít wiki stránku...',
);
