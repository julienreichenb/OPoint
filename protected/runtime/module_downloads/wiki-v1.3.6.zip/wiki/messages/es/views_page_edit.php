<?php

return [
    '<strong>Create</strong> new page' => '<strong>Crear</strong> nueva página',
    '<strong>Edit</strong> page' => '<strong>Editar</strong> página',
    'New page title' => 'Nuevo título de la página',
];
