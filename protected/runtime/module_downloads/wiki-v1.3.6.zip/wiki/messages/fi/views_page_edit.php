<?php

return [
    '<strong>Create</strong> new page' => '<strong>Luo</strong> uusi sivu',
    '<strong>Edit</strong> page' => '<strong>Muokkaa</strong> sivua',
    'New page title' => 'Uusi sivun nimi',
];
