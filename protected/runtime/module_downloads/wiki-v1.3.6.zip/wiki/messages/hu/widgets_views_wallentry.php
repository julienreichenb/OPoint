<?php
return array (
  'Open wiki page...' => 'Wiki oldal megnyitása...',
);
