Changelog
=========

1.0.2  (7 September, 2018)
------------------------
- Fix: Reduced api caching time to 600 seconds


1.0.1  (09 August, 2018)
------------------------
- Fix: Exception if organization api is not configured


1.0.0
---------------------
Initial release
