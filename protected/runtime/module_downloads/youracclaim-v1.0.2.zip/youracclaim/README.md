## Description

Integrates Acclaim badges from https://www.youracclaim.com/ to users profiles.


### Features

- Organization API to seamless integrate badges of all users without interaction
- OAuth2 API integration for third party badge support
- Integrates badges also in the Popover-VCard module if available
  

__Author:__ HumHub
__Author website:__ [www.humhub.org](http://www.humhub.org)


