<?php
return array (
  'Only visible for space admins' => 'Nur für Space-Admins sichtbar',
  'Open in new window' => 'In neuem Fenster öffnen',
  'page' => 'Seite',
);
