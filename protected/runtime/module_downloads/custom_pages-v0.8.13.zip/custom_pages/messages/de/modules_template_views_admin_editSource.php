<?php
return array (
  'Add Element' => 'Element hinzufügen',
  'Edit All' => 'Alle bearbeiten',
  'Edit template \'{templateName}\'' => 'Vorlage \'{templateName}\'  bearbeiten',
  'Here you can edit the source of your template by defining the template layout and adding content elements. Each element can be assigned with a default content and additional definitions.' => 'Hier kannst du die Quelle deiner Vorlage bearbeiten, indem du das Layout der Vorlage definierst und Inhaltselemente hinzufügst. Jedes Element kann mit einem Standardinhalt und zusätzlichen Definitionen versehen werden.',
  'You haven\'t saved your last changes yet. Do you want to leave without saving?' => 'Sie haben Ihre letzten Änderungen noch nicht gespeichert. Verlassen, ohne zu speichern?',
);
