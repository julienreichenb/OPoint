<?php
return array (
  'Activate PHP based Pages and Snippets' => 'PHP-basierte Seiten und Schnipsel aktivieren',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'Wenn deaktiviert, sind bestehende PHP-Seiten immer noch online, können aber nicht erstellt werden.',
  'PHP view path for custom space pages' => 'PHP-View-Pfad für benutzerdefinierte Space-Seiten',
  'PHP view path for custom space snippets' => 'PHP-View-Pfad für benutzerdefinierte Space-Schnipsel',
  'PHP view path for global custom pages' => 'PHP View-Pfad für globale benutzerdefinierte Seiten',
  'PHP view path for global custom snippets' => 'PHP-View-Pfad für globale benutzerdefinierte Schnipsel',
  'The given view file path does not exist.' => 'Der angegebene View-Dateipfad existiert nicht.',
);
