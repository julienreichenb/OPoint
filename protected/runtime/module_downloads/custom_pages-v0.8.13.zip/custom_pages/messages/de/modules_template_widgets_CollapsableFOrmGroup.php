<?php
return array (
  'Show less' => 'Weniger anzeigen',
  'Show more' => 'Mehr anzeigen',
);
