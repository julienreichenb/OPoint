<?php
return array (
  'Are you sure you want to delete this container item?' => 'Willst du dieses Container Element wirklich löschen?',
  'Do you really want to delete this content?' => 'Willst du diesen Inhalt wirklich löschen?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'Willst du dieses Element wirklich löschen? <br />Das Löschen wirkt sich auf alle Seiten aus, die diese Vorlage verwenden.',
);
