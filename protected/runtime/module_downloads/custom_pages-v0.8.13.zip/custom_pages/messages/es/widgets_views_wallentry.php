<?php
return array (
  'Open page...' => 'Abrir página...',
);
