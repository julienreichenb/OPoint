<?php
return array (
  'Choose a template' => 'አንድ አብነት ይምረጡ',
  'Template' => 'አብነት',
);
