<?php
return array (
  'Empty Image' => 'ባዶ ምስል',
);
