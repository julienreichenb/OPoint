<?php
return array (
  'Only visible for space admins' => 'ለምህዳር አስተዳዳሪዎች ብቻ የሚታይ',
  'Open in new window' => 'በአዲስ መስኮት ውስጥ ክፈት',
  'page' => 'ገፅ',
);
