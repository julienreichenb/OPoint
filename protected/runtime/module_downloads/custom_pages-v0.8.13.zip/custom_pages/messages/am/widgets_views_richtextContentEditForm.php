<?php
return array (
  'less' => 'ያነሰ',
  'more' => 'ብዙ',
);
