<?php
return array (
  'Activate PHP based Pages and Snippets' => 'አገልግሎቱ የሚሰጡ መሰረታቸውን PHP ላይ ያደረጉ ገፃችና ቁንፅልመረጃዎች',
  'If disabled, existing php pages will still be online, but can\'t be created.' => 'የማይሰራ ከሆነ፣ ቀድሞ የነበረው የpHP ገፅ አገልግሎት የሚሰጥ ይሆናል። ነገር ግን መፍጠር አይቻልም።',
  'PHP view path for custom space pages' => 'ለነባሪ የምህዳር ገፃች የሚሆን የPHP እይታ መንገድ',
  'PHP view path for custom space snippets' => 'ለነባሪ የምህዳር ቁንፅል መረጃ የሚሆን የphp እይታ መንገድ',
  'PHP view path for global custom pages' => 'ሉላዊ ለነባሪ ገፃች የሚሆን የphp እይታ መንገድ',
  'PHP view path for global custom snippets' => 'ለሉላዊ የነባሪ ቁንፅል መረጃ የሚሆን የphp እይታ መንገድ',
  'The given view file path does not exist.' => 'የቀረበው የፋይል መመልከቻ መንገድ አልተገኘም',
);
