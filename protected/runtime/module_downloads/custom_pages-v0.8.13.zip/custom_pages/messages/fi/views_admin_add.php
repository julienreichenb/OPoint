<?php

return [
    'Add new {pageType}' => '',
    'Create new template' => '',
    'Edit template' => '',
    'Settings' => '',
];
