<?php
return array (
  'none' => 'ምንም',
);
