<?php
return array (
  'Empty Richtext' => 'ባዶ @Richtext@',
  'Empty Text' => 'ባዶ ፅሁፍ',
);
