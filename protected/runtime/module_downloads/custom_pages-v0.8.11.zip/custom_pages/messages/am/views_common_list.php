<?php
return array (
  'Create new {label}' => 'አዲስ {label} ይፍጠሩ',
  'No {label} entry created yet!' => 'እስካሁን ምንም {label} ማስገቢያ አልተፈጠረም',
  'This page lists all available {label} entries.' => 'ይህ ገፅ ሁሉንም የ{label} ማስገቢያዎችን ይዘረዝራል።',
);
