<?php
return array (
  'Are you sure you want to delete this container item?' => 'የዚህን ማዕቀፍ ነገሮች ማጥፋት መፈለግዎን እርግጠኛ ኖት?',
  'Do you really want to delete this content?' => 'ይህን ይዘት ማጥፋት መፈለግዎን እርግጠኛ ኖት?',
  'Do you really want to delete this element? <br />The deletion will affect all pages using this template.' => 'ይህን አካል ለማጥፋት መፈለግዎን እርግጠኛ ነዎት? <br /> የሚያጠፉ ከሆነ ይህን አብነት የሚጠቀሙ ገፆች በሙሉ ሊታወኩ ይችላሉ።',
);
