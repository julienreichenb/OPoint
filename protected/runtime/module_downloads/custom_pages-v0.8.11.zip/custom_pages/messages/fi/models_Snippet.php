<?php

return [
    'Content' => '',
    'Sidebar' => '',
    'snippet' => '',
];
