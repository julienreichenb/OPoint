<?php

return [
    'Empty Richtext' => '',
    'Empty Text' => '',
];
