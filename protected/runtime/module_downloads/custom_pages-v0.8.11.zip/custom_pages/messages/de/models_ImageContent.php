<?php
return array (
  'Empty Image' => 'Leeres Bild',
);
