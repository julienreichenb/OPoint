<?php
return array (
  'Here you can manage your snipped layouts. Snippet layouts are templates, which can be included into sidebars.' => 'Hier kannst du deine Schnipsel-Layouts verwalten. Schnipsel-Layouts sind Vorlagen, die in Sidebars eingebunden werden können.',
);
