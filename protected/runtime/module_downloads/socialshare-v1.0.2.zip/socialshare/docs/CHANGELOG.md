Changelog
=========

1.0.2 - 24 August 2018
-----------------------
- Fix: PHP 7.2 compatibility




