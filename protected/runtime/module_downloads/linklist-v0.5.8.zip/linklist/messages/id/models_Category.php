<?php
return array (
  'Description' => 'Deskripsi',
  'Sort Order' => '',
  'Title' => 'Judul',
);
