<?php
return array (
  'Category' => '',
  'Description' => 'توضيج',
  'Sort Order' => '',
  'Title' => 'العنوان',
);
