<?php
return array (
  'Description' => 'Açıklama',
  'Sort Order' => 'Sıralama',
  'Title' => 'Başlık',
);
