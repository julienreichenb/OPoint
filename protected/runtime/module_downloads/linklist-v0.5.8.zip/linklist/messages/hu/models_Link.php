<?php
return array (
  'Category' => '',
  'Description' => 'Leírás',
  'Sort Order' => '',
  'Title' => 'Naslov',
);
