<?php
return array (
  'Category' => 'Categoria',
  'Description' => 'Descrição',
  'Sort Order' => 'Ordem de Classificação',
  'Title' => 'Título',
);
