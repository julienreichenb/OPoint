<?php
return array (
  'Category' => '',
  'Description' => '',
  'Sort Order' => 'Сортувати за номером',
  'Title' => 'Заголовок',
);
