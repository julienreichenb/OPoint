<?php

return [
    'Description' => '',
    'Sort Order' => '',
    'Title' => '',
];
