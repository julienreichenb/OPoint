<?php
return array (
  'Description' => 'Description',
  'Sort Order' => 'Ordre de tri',
  'Title' => 'Titre',
);
