<?php
return array (
  'Description' => 'Opis',
  'Sort Order' => 'Sortuj',
  'Title' => 'Tytuł',
);
