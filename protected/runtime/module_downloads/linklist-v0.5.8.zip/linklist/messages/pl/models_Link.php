<?php
return array (
  'Category' => '',
  'Description' => 'Opis',
  'Sort Order' => 'Sortuj',
  'Title' => 'Tytuł',
);
