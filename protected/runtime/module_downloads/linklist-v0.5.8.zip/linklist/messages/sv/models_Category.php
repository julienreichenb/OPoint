<?php
return array (
  'Description' => 'Beskrivning',
  'Sort Order' => 'Sorteringsordning',
  'Title' => 'Rubrik',
);
