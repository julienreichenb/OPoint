<?php
return array (
  'Category' => '',
  'Description' => '',
  'Sort Order' => 'Ordem de classificação',
  'Title' => 'Título',
);
