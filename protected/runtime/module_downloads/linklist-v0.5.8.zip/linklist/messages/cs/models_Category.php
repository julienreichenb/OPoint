<?php
return array (
  'Description' => 'Popis',
  'Sort Order' => 'Řazení',
  'Title' => 'Název',
);
