<?php
return array (
  'Description' => 'Descripció',
  'Sort Order' => 'Ordre de classificació',
  'Title' => 'Títol',
);
