<?php
return array (
  'Description' => 'Описание',
  'Sort Order' => 'Порядок сортировки',
  'Title' => 'Заголовок',
);
