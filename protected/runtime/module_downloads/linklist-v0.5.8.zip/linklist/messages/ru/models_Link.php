<?php
return array (
  'Category' => '',
  'Description' => 'Описание',
  'Sort Order' => 'Порядок сортировки',
  'Title' => 'Заголовок',
);
