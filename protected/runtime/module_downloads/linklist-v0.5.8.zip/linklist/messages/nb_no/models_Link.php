<?php
return array (
  'Category' => 'Kategori',
  'Description' => 'Beskrivelse',
  'Sort Order' => 'Sorterings rekkefølge',
  'Title' => 'Tittel',
);
