<?php
return array (
  'Description' => 'Περιγραφή',
  'Sort Order' => '',
  'Title' => 'Τίτλος',
);
