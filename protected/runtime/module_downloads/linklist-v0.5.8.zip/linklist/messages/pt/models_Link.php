<?php
return array (
  'Category' => '',
  'Description' => 'Descrição',
  'Sort Order' => '',
  'Title' => 'Título',
);
