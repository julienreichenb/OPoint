<?php
return array (
  'Description' => 'Descrição',
  'Sort Order' => '',
  'Title' => 'Título',
);
