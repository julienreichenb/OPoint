Changelog
=========


0.5.8 (October 14, 2018)
---------------------------
- Fix: Added menu icon
- Enh: Translation updates

