<?php

return [
    '<strong>Add</strong> new {type} element' => '',
    '<strong>Edit</strong> element {name}' => '',
    '<strong>Edit</strong> elements of {templateName}' => '',
    '<strong>Edit</strong> {templateName}' => '',
    'Template not found!' => '',
    'The template could not be deleted, please get sure that this template is not in use.' => '',
];
