<?php

return [
    '<strong>Confirm</strong> content deletion' => '',
    '<strong>Confirm</strong> element deletion' => '',
    '<strong>Confirm</strong> container item deletion' => '<strong>Vahvista</strong> säilöryhmän poisto',
];
