<?php

return [
    'Allow multiple items?' => '',
    'Allowed Templates' => '',
    'Render items as inline-blocks within the inline editor?' => '',
];
