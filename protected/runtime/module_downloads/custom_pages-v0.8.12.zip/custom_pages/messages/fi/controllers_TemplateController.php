<?php

return [
    '<strong>Edit</strong> {type} element' => '',
    'Access denied!' => '',
    'Empty content elements cannot be delted!' => '',
    'You are not allowed to delete default content!' => '',
    'Invalid request data!' => 'Virheelinen pyyntö!',
];
