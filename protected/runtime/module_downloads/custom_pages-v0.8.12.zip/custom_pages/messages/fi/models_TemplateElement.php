<?php

return [
    'Label' => '',
    'Placeholder name' => '',
    'The element name must contain at least two characters without spaces or special signs except \'_\'' => '',
    'The given element name is already in use for this template.' => '',
];
