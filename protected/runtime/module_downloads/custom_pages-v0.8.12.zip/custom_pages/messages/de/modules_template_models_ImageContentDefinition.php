<?php
return array (
  'Height' => 'Höhe',
  'Style' => 'Style',
  'Width' => 'Breite',
);
