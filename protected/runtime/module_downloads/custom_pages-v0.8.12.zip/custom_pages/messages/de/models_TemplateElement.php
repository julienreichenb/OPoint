<?php
return array (
  'Label' => 'Label',
  'Placeholder name' => 'Platzhalterbezeichnung',
  'The element name must contain at least two characters without spaces or special signs except \'_\'' => 'Der Elementname muss mindestens zwei Zeichen ohne Leerzeichen oder Sonderzeichen enthalten, außer \'_\'.',
  'The given element name is already in use for this template.' => 'Der angegebene Elementname wird bereits für diese Vorlage verwendet.',
);
