<?php
/**
 * Created by PhpStorm.
 * User: 001101
 * Date: 25.01.2017
 * Time: 04:02
 */

return array (
    'Use empty content' => 'Leeren Inhalt benutzen',
);