<?php
return array (
  'Empty Richtext' => 'Leerer Richtext',
  'Empty Text' => 'Leerer Text',
);
