<?php
return array (
  'Content' => 'Inhalt',
  'Sidebar' => 'Seitenleiste (Sidebar)',
  'snippet' => 'Schnipsel',
);
