<?php
return array (
  'Here you can manage your template layouts. Layouts are the root of your template pages and can not be combined with other templates.' => 'Hier kannst du deine Vorlagen-Layouts verwalten. Layouts sind die Grundlage deiner Vorlagenseiten und können nicht mit anderen Vorlagen kombiniert werden.',
);
