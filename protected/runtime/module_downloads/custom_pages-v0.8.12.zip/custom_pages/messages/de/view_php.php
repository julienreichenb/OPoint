<?php
return array (
  'View not found' => 'View nicht gefunden',
);
